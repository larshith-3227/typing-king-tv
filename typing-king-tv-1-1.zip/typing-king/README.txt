TYPING KING - Android TV

This folder is the complete source project. See README.md for setup and build instructions.
