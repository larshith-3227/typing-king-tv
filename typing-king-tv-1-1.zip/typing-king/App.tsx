import React, { useEffect, useMemo, useState } from 'react';
import {
  Image,
  Pressable,
  StatusBar,
  StyleSheet,
  Text,
  View,
  useTVEventHandler,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { setAudioModeAsync, useAudioPlayer } from 'expo-audio';

type Screen = 'home' | 'learn' | 'settings' | 'game' | 'result';
type Difficulty = 'easy' | 'medium' | 'hard';
type Duration = 60 | 120;

type Result = {
  score: number;
  words: number;
  correctChars: number;
  wpm: number;
  duration: Duration;
  difficulty: Difficulty;
};

const HIGH_SCORE_KEY = 'typing-king-high-scores-v1';
const GAME_WORDS: Record<Difficulty, string[]> = {
  easy: [
    'cat', 'dog', 'sun', 'book', 'tree', 'fish', 'ball', 'home', 'milk', 'rain',
    'star', 'moon', 'blue', 'green', 'school', 'happy', 'water', 'apple', 'bread', 'music',
  ],
  medium: [
    'garden', 'planet', 'window', 'friend', 'orange', 'computer', 'keyboard', 'teacher',
    'picture', 'family', 'morning', 'holiday', 'country', 'science', 'football', 'library',
    'student', 'journey', 'rainbow', 'reading',
  ],
  hard: [
    'javascript', 'programming', 'television', 'adventure', 'knowledge', 'beautiful',
    'important', 'challenge', 'excellent', 'education', 'imagination', 'technology',
    'environment', 'communication', 'understanding', 'development', 'information',
    'concentration', 'achievement', 'responsibility',
  ],
};

const KEYBOARD = [
  ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
  ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'],
  ['Z', 'X', 'C', 'V', 'B', 'N', 'M'],
];

const GAME_MUSIC = require('./assets/music/game-music.wav');
const CORRECT_SOUND = require('./assets/sounds/correct.wav');
const WRONG_SOUND = require('./assets/sounds/wrong.wav');
const FINISH_SOUND = require('./assets/sounds/finish.wav');

function randomWord(difficulty: Difficulty, previous = '') {
  const list = GAME_WORDS[difficulty];
  let next = list[Math.floor(Math.random() * list.length)];
  while (list.length > 1 && next === previous) {
    next = list[Math.floor(Math.random() * list.length)];
  }
  return next;
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('home');
  const [duration, setDuration] = useState<Duration>(60);
  const [difficulty, setDifficulty] = useState<Difficulty>('easy');
  const [musicOn, setMusicOn] = useState(true);
  const [soundOn, setSoundOn] = useState(true);
  const [highScores, setHighScores] = useState<Record<string, number>>({});

  const [timeLeft, setTimeLeft] = useState<Duration>(60);
  const [word, setWord] = useState('');
  const [typed, setTyped] = useState('');
  const [score, setScore] = useState(0);
  const [wordsCompleted, setWordsCompleted] = useState(0);
  const [correctChars, setCorrectChars] = useState(0);
  const [row, setRow] = useState(0);
  const [column, setColumn] = useState(0);
  const [result, setResult] = useState<Result | null>(null);

  const music = useAudioPlayer(GAME_MUSIC);
  const correct = useAudioPlayer(CORRECT_SOUND);
  const wrong = useAudioPlayer(WRONG_SOUND);
  const finish = useAudioPlayer(FINISH_SOUND);

  const scoreKey = `${duration}-${difficulty}`;
  const highScore = highScores[scoreKey] ?? 0;
  const selectedKey = useMemo(() => KEYBOARD[row][column], [row, column]);

  useEffect(() => {
    loadScores();
    setAudioModeAsync({ playsInSilentMode: true, interruptionMode: 'mixWithOthers' }).catch(() => {});
  }, []);

  useEffect(() => {
    if (screen === 'game' && musicOn) {
      music.loop = true;
      music.volume = 0.38;
      music.play();
    } else {
      music.pause();
    }
  }, [screen, musicOn]);

  useEffect(() => {
    if (screen !== 'game') return;
    if (timeLeft <= 0) {
      finishGame();
      return;
    }
    const timer = setInterval(() => {
      setTimeLeft((value) => (value > 0 ? (value - 1) as Duration : 0 as Duration));
    }, 1000);
    return () => clearInterval(timer);
  }, [screen, timeLeft]);

  useTVEventHandler((event) => {
    const type = event?.eventType;
    if (!type) return;

    if (screen === 'home') {
      if (type === 'select' || type === 'enter' || type === 'playPause') startGame();
      if (type === 'down') setScreen('learn');
    } else if (screen === 'learn') {
      if (type === 'select' || type === 'enter') startGame();
      if (type === 'back' || type === 'left') setScreen('home');
      if (type === 'down') setScreen('settings');
    } else if (screen === 'settings') {
      if (type === 'back' || type === 'left') setScreen('home');
      if (type === 'select' || type === 'enter') cycleSetting();
      if (type === 'up' || type === 'down' || type === 'left' || type === 'right') moveSetting(type);
    } else if (screen === 'game') {
      if (type === 'up' || type === 'down' || type === 'left' || type === 'right') moveKeyboard(type);
      if (type === 'select' || type === 'enter') pressSelectedKey();
      if (type === 'back') setScreen('home');
    } else if (screen === 'result') {
      if (type === 'select' || type === 'enter' || type === 'playPause') startGame();
      if (type === 'back' || type === 'left') setScreen('home');
    }
  });

  async function loadScores() {
    try {
      const raw = await AsyncStorage.getItem(HIGH_SCORE_KEY);
      if (raw) setHighScores(JSON.parse(raw));
    } catch {}
  }

  async function saveScore(value: number) {
    const next = { ...highScores, [scoreKey]: Math.max(value, highScore) };
    setHighScores(next);
    await AsyncStorage.setItem(HIGH_SCORE_KEY, JSON.stringify(next));
  }

  function startGame() {
    setTimeLeft(duration);
    setWord(randomWord(difficulty));
    setTyped('');
    setScore(0);
    setWordsCompleted(0);
    setCorrectChars(0);
    setRow(0);
    setColumn(0);
    setResult(null);
    setScreen('game');
  }

  function finishGame() {
    const minutes = duration / 60;
    const wpm = Math.round((correctChars / 5) / minutes);
    const finalResult: Result = {
      score,
      words: wordsCompleted,
      correctChars,
      wpm,
      duration,
      difficulty,
    };
    setResult(finalResult);
    if (score > highScore) saveScore(score).catch(() => {});
    if (soundOn) {
      finish.seekTo(0).catch(() => {});
      finish.play();
    }
    setScreen('result');
  }

  function typeLetter(letter: string) {
    const expected = word[typed.length]?.toUpperCase();
    const pressed = letter.toUpperCase();

    // Requirement: do not accept another/wrong key. It simply does nothing.
    if (pressed !== expected) {
      if (soundOn) {
        wrong.seekTo(0).catch(() => {});
        wrong.play();
      }
      return;
    }

    const nextTyped = typed + pressed.toLowerCase();
    setTyped(nextTyped);
    setCorrectChars((value) => value + 1);
    setScore((value) => value + 1);

    if (nextTyped === word) {
      setWordsCompleted((value) => value + 1);
      setScore((value) => value + 10);
      setTyped('');
      setWord(randomWord(difficulty, word));
      if (soundOn) {
        correct.seekTo(0).catch(() => {});
        correct.play();
      }
    }
  }

  function pressSelectedKey() {
    typeLetter(selectedKey);
  }

  function moveKeyboard(direction: string) {
    setRow((currentRow) => {
      let nextRow = currentRow;
      let nextColumn = column;
      if (direction === 'up') nextRow = Math.max(0, currentRow - 1);
      if (direction === 'down') nextRow = Math.min(KEYBOARD.length - 1, currentRow + 1);
      if (direction === 'left') nextColumn = Math.max(0, column - 1);
      if (direction === 'right') nextColumn = Math.min(KEYBOARD[nextRow].length - 1, column + 1);
      nextColumn = Math.min(nextColumn, KEYBOARD[nextRow].length - 1);
      setColumn(nextColumn);
      return nextRow;
    });
  }

  function cycleSetting() {
    setDuration((value) => (value === 60 ? 120 : 60));
  }

  function moveSetting(direction: string) {
    if (direction === 'left' || direction === 'right') {
      setDuration((value) => (value === 60 ? 120 : 60));
    }
    if (direction === 'up' || direction === 'down') {
      setDifficulty((value) => {
        const values: Difficulty[] = ['easy', 'medium', 'hard'];
        const index = values.indexOf(value);
        const next = direction === 'down' ? Math.min(2, index + 1) : Math.max(0, index - 1);
        return values[next];
      });
    }
  }

  function Home() {
    return (
      <View style={styles.screen}>
        <View style={styles.homeLeft}>
          <Image source={require('./assets/logo.jpg')} style={styles.logo} resizeMode="contain" />
          <Text style={styles.tagline}>LEARN • PRACTISE • TEST YOUR TYPING SKILLS</Text>
          <Text style={styles.best}>Best: {highScore} points</Text>
        </View>
        <View style={styles.menu}>
          <MenuButton title="START GAME" onPress={startGame} autoFocus />
          <MenuButton title="LEARN HOW TO PLAY" onPress={() => setScreen('learn')} />
          <MenuButton title="SETTINGS" onPress={() => setScreen('settings')} />
          <Text style={styles.remote}>TV REMOTE: D-PAD + OK</Text>
        </View>
      </View>
    );
  }

  function Learn() {
    return (
      <View style={styles.screen}>
        <View style={styles.panelWide}>
          <Text style={styles.pageTitle}>HOW TO PLAY</Text>
          <Text style={styles.body}>Type the word shown at the top of the screen.</Text>
          <Text style={styles.body}>Use the TV remote to move the highlight and press OK.</Text>
          <Text style={styles.body}>Only the correct next letter is accepted. A different key will not advance the word.</Text>
          <View style={styles.rulesRow}>
            <Rule title="+1" text="correct letter" />
            <Rule title="+10" text="complete word" />
            <Rule title="60/120" text="seconds" />
          </View>
          <MenuButton title="START GAME" onPress={startGame} autoFocus />
          <MenuButton title="BACK" onPress={() => setScreen('home')} />
        </View>
      </View>
    );
  }

  function Settings() {
    return (
      <View style={styles.screen}>
        <View style={styles.panelWide}>
          <Text style={styles.pageTitle}>SETTINGS</Text>
          <SettingLine label="TIME" value={`${duration} seconds`} />
          <SettingLine label="DIFFICULTY" value={difficulty.toUpperCase()} />
          <SettingLine label="MUSIC" value={musicOn ? 'ON' : 'OFF'} />
          <SettingLine label="SOUND EFFECTS" value={soundOn ? 'ON' : 'OFF'} />
          <Text style={styles.bodySmall}>OK changes time. Up/Down changes difficulty. Use the buttons below for audio.</Text>
          <View style={styles.buttonRow}>
            <MenuButton title={musicOn ? 'MUSIC: ON' : 'MUSIC: OFF'} onPress={() => setMusicOn((v) => !v)} autoFocus />
            <MenuButton title={soundOn ? 'SOUND: ON' : 'SOUND: OFF'} onPress={() => setSoundOn((v) => !v)} />
          </View>
          <MenuButton title="BACK" onPress={() => setScreen('home')} />
        </View>
      </View>
    );
  }

  function Game() {
    const progress = word.length ? typed.length / word.length : 0;
    return (
      <View style={styles.screen}>
        <View style={styles.topBar}>
          <View><Text style={styles.statLabel}>SCORE</Text><Text style={styles.statValue}>{score}</Text></View>
          <View style={styles.centerTitle}><Text style={styles.gameTitle}>TYPING KING</Text><Text style={styles.mode}>{difficulty.toUpperCase()} • {duration}s</Text></View>
          <View><Text style={styles.statLabel}>TIME</Text><Text style={[styles.statValue, timeLeft <= 10 && styles.danger]}>{timeLeft}</Text></View>
        </View>

        <View style={styles.wordPanel}>
          <Text style={styles.typeLabel}>TYPE THIS WORD</Text>
          <Text style={styles.target}>{word}</Text>
          <View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${Math.round(progress * 100)}%` }]} /></View>
          <Text style={styles.typed}>{typed || ' '}</Text>
        </View>

        <View style={styles.keyboard}>
          {KEYBOARD.map((letters, r) => (
            <View key={r} style={styles.keyboardRow}>
              {letters.map((letter, c) => {
                const selected = r === row && c === column;
                return (
                  <Pressable key={letter} onPress={() => { setRow(r); setColumn(c); typeLetter(letter); }} style={[styles.key, selected && styles.keySelected]}>
                    <Text style={[styles.keyText, selected && styles.keyTextSelected]}>{letter}</Text>
                  </Pressable>
                );
              })}
            </View>
          ))}
        </View>
        <Text style={styles.help}>D-PAD to move • OK to type • Only the next correct key is accepted</Text>
      </View>
    );
  }

  function ResultScreen() {
    const isRecord = !!result && result.score > highScore;
    return (
      <View style={styles.screen}>
        <View style={styles.resultPanel}>
          <Text style={styles.pageTitle}>TIME'S UP!</Text>
          {isRecord && <Text style={styles.record}>NEW HIGH SCORE!</Text>}
          <Text style={styles.bigScore}>{result?.score ?? 0}</Text>
          <Text style={styles.resultLabel}>POINTS</Text>
          <View style={styles.resultsGrid}>
            <ResultStat label="WORDS" value={String(result?.words ?? 0)} />
            <ResultStat label="WPM" value={String(result?.wpm ?? 0)} />
            <ResultStat label="TIME" value={`${result?.duration ?? duration}s`} />
            <ResultStat label="BEST" value={String(Math.max(highScore, result?.score ?? 0))} />
          </View>
          <View style={styles.buttonRow}>
            <MenuButton title="PLAY AGAIN" onPress={startGame} autoFocus />
            <MenuButton title="HOME" onPress={() => setScreen('home')} />
          </View>
        </View>
      </View>
    );
  }

  let content: React.ReactNode;
  if (screen === 'home') content = <Home />;
  else if (screen === 'learn') content = <Learn />;
  else if (screen === 'settings') content = <Settings />;
  else if (screen === 'game') content = <Game />;
  else content = <ResultScreen />;

  return <View style={styles.root}><StatusBar hidden />{content}</View>;
}

function MenuButton({ title, onPress, autoFocus = false }: { title: string; onPress: () => void; autoFocus?: boolean }) {
  return <Pressable hasTVPreferredFocus={autoFocus} onPress={onPress} style={({ focused, pressed }) => [styles.menuButton, (focused || pressed) && styles.menuButtonFocused]}><Text style={styles.menuText}>{title}</Text></Pressable>;
}

function Rule({ title, text }: { title: string; text: string }) {
  return <View style={styles.rule}><Text style={styles.ruleTitle}>{title}</Text><Text style={styles.ruleText}>{text}</Text></View>;
}

function SettingLine({ label, value }: { label: string; value: string }) {
  return <View style={styles.settingLine}><Text style={styles.settingLabel}>{label}</Text><Text style={styles.settingValue}>{value}</Text></View>;
}

function ResultStat({ label, value }: { label: string; value: string }) {
  return <View style={styles.resultStat}><Text style={styles.resultStatValue}>{value}</Text><Text style={styles.resultStatLabel}>{label}</Text></View>;
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0A5FA9' },
  screen: { flex: 1, flexDirection: 'row', paddingHorizontal: 54, paddingVertical: 34, backgroundColor: '#0A5FA9' },
  homeLeft: { width: '46%', alignItems: 'center', justifyContent: 'center' },
  logo: { width: 330, height: 330, borderRadius: 165 },
  tagline: { marginTop: 14, color: '#FFFFFF', fontSize: 18, fontWeight: '800', textAlign: 'center', letterSpacing: 1 },
  best: { marginTop: 12, color: '#D8F2FF', fontSize: 18, fontWeight: '700' },
  menu: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 30 },
  menuButton: { width: 390, minHeight: 68, marginVertical: 8, borderRadius: 18, backgroundColor: '#FFFFFF', borderWidth: 4, borderColor: 'transparent', alignItems: 'center', justifyContent: 'center' },
  menuButtonFocused: { borderColor: '#FFD83D', transform: [{ scale: 1.04 }] },
  menuText: { color: '#07558F', fontSize: 23, fontWeight: '900', letterSpacing: 0.5 },
  remote: { marginTop: 16, color: '#D8F2FF', fontSize: 16, fontWeight: '700' },
  panelWide: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 70 },
  pageTitle: { color: '#FFFFFF', fontSize: 44, fontWeight: '900', letterSpacing: 2, marginBottom: 18 },
  body: { maxWidth: 900, color: '#FFFFFF', fontSize: 21, lineHeight: 32, textAlign: 'center', marginVertical: 5 },
  bodySmall: { color: '#D8F2FF', fontSize: 16, marginVertical: 10, textAlign: 'center' },
  rulesRow: { flexDirection: 'row', gap: 18, marginVertical: 20 },
  rule: { width: 180, padding: 15, borderRadius: 16, backgroundColor: '#0873C9', alignItems: 'center' },
  ruleTitle: { color: '#FFD83D', fontSize: 30, fontWeight: '900' },
  ruleText: { color: '#FFFFFF', fontSize: 15, marginTop: 5 },
  settingLine: { width: 650, minHeight: 56, paddingHorizontal: 22, marginVertical: 4, borderRadius: 13, backgroundColor: '#0873C9', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  settingLabel: { color: '#FFFFFF', fontSize: 20, fontWeight: '800' },
  settingValue: { color: '#FFD83D', fontSize: 20, fontWeight: '900' },
  buttonRow: { flexDirection: 'row', gap: 18, alignItems: 'center', justifyContent: 'center' },
  topBar: { position: 'absolute', top: 22, left: 54, right: 54, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  statLabel: { color: '#D8F2FF', fontSize: 13, fontWeight: '800', letterSpacing: 2 },
  statValue: { color: '#FFFFFF', fontSize: 34, fontWeight: '900' },
  centerTitle: { alignItems: 'center' },
  gameTitle: { color: '#FFFFFF', fontSize: 28, fontWeight: '900', letterSpacing: 2 },
  mode: { color: '#D8F2FF', fontSize: 13, fontWeight: '800', marginTop: 2 },
  danger: { color: '#FFD83D' },
  wordPanel: { position: 'absolute', top: 105, left: 54, right: 54, alignItems: 'center' },
  typeLabel: { color: '#D8F2FF', fontSize: 16, fontWeight: '800', letterSpacing: 2 },
  target: { color: '#FFFFFF', fontSize: 52, fontWeight: '900', letterSpacing: 3, marginTop: 3 },
  typed: { color: '#FFD83D', fontSize: 24, fontWeight: '800', minHeight: 31, marginTop: 3 },
  progressTrack: { width: 560, height: 9, marginTop: 8, borderRadius: 5, backgroundColor: '#07518A', overflow: 'hidden' },
  progressFill: { height: '100%', backgroundColor: '#FFD83D' },
  keyboard: { position: 'absolute', left: 54, right: 54, bottom: 48, alignItems: 'center' },
  keyboardRow: { flexDirection: 'row', marginVertical: 3 },
  key: { width: 58, height: 52, marginHorizontal: 4, borderRadius: 12, backgroundColor: '#FFFFFF', borderWidth: 4, borderColor: 'transparent', alignItems: 'center', justifyContent: 'center' },
  keySelected: { borderColor: '#FFD83D', backgroundColor: '#EAF8FF', transform: [{ scale: 1.08 }] },
  keyText: { color: '#07558F', fontSize: 21, fontWeight: '900' },
  keyTextSelected: { color: '#053F68' },
  help: { position: 'absolute', bottom: 14, left: 0, right: 0, color: '#D8F2FF', fontSize: 14, textAlign: 'center', fontWeight: '700' },
  resultPanel: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  record: { color: '#FFD83D', fontSize: 22, fontWeight: '900', marginBottom: 4 },
  bigScore: { color: '#FFFFFF', fontSize: 78, fontWeight: '900', lineHeight: 86 },
  resultLabel: { color: '#D8F2FF', fontSize: 15, fontWeight: '800', letterSpacing: 3 },
  resultsGrid: { flexDirection: 'row', gap: 20, marginVertical: 24 },
  resultStat: { width: 150, minHeight: 80, borderRadius: 16, backgroundColor: '#0873C9', alignItems: 'center', justifyContent: 'center' },
  resultStatValue: { color: '#FFFFFF', fontSize: 28, fontWeight: '900' },
  resultStatLabel: { color: '#D8F2FF', fontSize: 12, fontWeight: '800', marginTop: 2 },
});
