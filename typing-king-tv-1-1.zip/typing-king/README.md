# Typing King — Android TV

A single-player cartoon/simple typing game for Android TV.

## Features

- 60-second and 120-second games
- Learn mode and Test mode
- Easy, Medium, and Hard difficulty
- TV remote D-pad + OK support
- Only the correct next key is accepted; other keys do not advance the word
- Score and WPM tracking
- Persistent high scores with AsyncStorage
- Background music and sound effects
- Offline word lists
- Uses the supplied Typing King logo

## Audio

This project contains short original WAV placeholders for music and sound effects so the project can run immediately. Replace `assets/music/game-music.wav` with music you have permission to use. You can also replace the WAV sound effects with your own files, keeping the same filenames and formats.

## Setup

1. Install Node.js LTS and Android Studio.
2. Install dependencies:

   npm install

3. Generate the Android TV native project:

   EXPO_TV=1 npx expo prebuild --clean

4. Start an Android TV emulator in Android Studio.
5. Run:

   EXPO_TV=1 npx expo run:android

On Windows PowerShell, use:

   $env:EXPO_TV="1"; npx expo prebuild --clean
   $env:EXPO_TV="1"; npx expo run:android

## Play Store build

After testing:

   npx eas login
   npx eas build --platform android --profile production_tv

The production profile is configured for an Android App Bundle.

## Important

The package ID is `com.typingking.tv`. Change it in `app.json` if you want a different unique application ID before publishing.
